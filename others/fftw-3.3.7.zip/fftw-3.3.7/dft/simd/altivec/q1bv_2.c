/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-altivec.h"
#include "../common/q1bv_2.c"
