package cz.sa.dovolena.similarityclient.utils;

/**
 *
 * @author Dobroslav Pelc
 * @email dobroslav.pelc@studentagency.cz
 */
public enum ChecksumAlghorithm {

    MD5,
    SHA1
}
