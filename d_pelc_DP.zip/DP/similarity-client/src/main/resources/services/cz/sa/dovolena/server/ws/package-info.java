@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.server.dovolena.sa.cz/")
package cz.sa.dovolena.server.ws;
